#include"string.h"

int main()
{
	String s1;
	String s2 = "Initialize";
	String s3("Iniitial String u", 9, 3);
	String s4("A string here");
	String s5("Another sequence", 12);
	String s6(10, '&');
	cout << s3 << s4 << s5 << s6 << endl;
	system("pause");
	return 0;
}