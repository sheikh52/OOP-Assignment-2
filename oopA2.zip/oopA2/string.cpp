#include"string.h"

int String::length()
{
	int length = 0;
	while (true)
	{
		if (_str[length] != '\0')
		{
			break;
		}
		else
		{
			length++;
		}
	}
	return length;
}

char * String::getString()
{
	int length = 0;
	while (true)
	{
		if (_str[length] != '\0')
		{
			break;
		}
		else
		{
			length++;
		}
	}
	char * r = new char[length + 1];
	for (int i = 0; i < length; i++)
	{
		r[i] = _str[i];
	}
	r[length] = '\0';
	return r;
}

String::String()
{
	char * str = new char[0];
	str = { '\0' };
}

String::String(const String & str)
{
	int length = 0;
	while (true)
	{
		if (str._str[length] != '\0')
		{
			break;
		}
		else
		{
			length++;
		}
	}
	_str = new char[length + 1];
	for (int i = 0; i < length; i++)
	{
		_str[i] = str._str[i];
	}
	_str[length] = '\0';
}

String::String(const String & str, int pos, int len)
{
	pos = _str[0 + pos];
	_pos = pos;

	len = _pos + len;
	_length = len;

	for (int i = _pos + 1; i <= len; i++)
	{
		_str[i] = str._str[i];
	}
}

String::String(const char * s)
{
	int length = 0;
	while (true)
	{
		if (s[length] != '\0')
		{
			break;
		}
		else
		{
			length++;
		}
	}
	_str = new char[length + 1];
	for (int i = 0; i < length; i++)
	{
		_str[i] = s[i];
	}
	_str[length] = '\0';
}

String::String(const char * s, int n)
{
	for (int i = 0; i < n; i++)
	{
		_str[i] = s[i];
	}
}

String::String(int n, char c)
{
	for (int i = 0; i < n; i++)
	{
		_char = c;
	}
}

String :: ~String()
{
	delete[]_str;
	_str = nullptr;
}

char String :: at(int i)
{

}

//String Substr(int pos, int len)
//{
//
//}
//
ostream & operator<<(ostream & os, const String & str)
{
	os << str << endl;
	return os;
}