#include<iostream>
using namespace std;

class String
{
	int _pos;
	int _length;
	int _num;
	char _char;
	char * _str;
public:
	String();
	String(const String & str);
	String(const String & str, int pos, int len);
	String(const char * s);
	String(const char * s, int n);
	String(int n, char c);
	~String();
	void display();
	int getPosition();
	int getLen();
	int getN();
	char getChractr();
	char * getString();
	int length();
	char at(int i);
//	String Substr(int pos, int len) const;
	friend ostream & operator<<(ostream & os, const String & str);
};